package util;

public class OrderState {

	public OrderState() {
		// TODO Auto-generated constructor stub
	}

}
