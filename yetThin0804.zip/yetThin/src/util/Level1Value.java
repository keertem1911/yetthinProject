package util;

public class Level1Value {

	public Level1Value() {
		// TODO Auto-generated constructor stub
	}

}
