package com.yetthin.web.serviceImp;

import com.yetthin.web.common.Md5UnitTool;

public class BaseService {
		

}
