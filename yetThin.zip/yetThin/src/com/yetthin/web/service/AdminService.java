package com.yetthin.web.service;

import com.yetthin.web.domain.Admin;

public interface AdminService extends BaseService<Admin>{

}
