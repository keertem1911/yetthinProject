package com.yetthin.web.service;

import com.yetthin.web.domain.TempCode;

public interface TempCodeService extends BaseService<TempCode>{

}
