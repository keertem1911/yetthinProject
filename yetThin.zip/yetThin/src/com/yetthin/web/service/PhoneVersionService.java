package com.yetthin.web.service;

import com.yetthin.web.domain.PhoneVersion;

public interface PhoneVersionService extends BaseService<PhoneVersion>{

}
