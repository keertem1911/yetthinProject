package util;

public class Contract {

	public long contractId;
	public String symbol;//symbol name
	public String secType;//trade type
	public String exchange;//exchange
	public String currency;//currency
	public String localSymbol;//
	public Contract() {
		// TODO Auto-generated constructor stub
	}

}
