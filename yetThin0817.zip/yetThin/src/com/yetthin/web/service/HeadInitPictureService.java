package com.yetthin.web.service;

import com.yetthin.web.domain.HeadPicture;

public interface HeadInitPictureService extends BaseService<HeadPicture>{
		public String getPictureList(String path);
		 
		
}
