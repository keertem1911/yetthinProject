package com.yetthin.web.service;

import java.util.List;

public interface JtdoaAPIService {
}
