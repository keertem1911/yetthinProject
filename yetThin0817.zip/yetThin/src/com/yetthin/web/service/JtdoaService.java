package com.yetthin.web.service;

public interface JtdoaService {

	String[] getL1(int huShen);

}
