package com.yetthin.web.domain;

public class UpPersonComment {
		private String name;
		private String repateContext;
		private String userid;
		private String fromName;
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getRepateContext() {
			return repateContext;
		}
		public void setRepateContext(String repateContext) {
			this.repateContext = repateContext;
		}
		public String getUserid() {
			return userid;
		}
		public void setUserid(String userid) {
			this.userid = userid;
		}
		public String getFromName() {
			return fromName;
		}
		public void setFromName(String fromName) {
			this.fromName = fromName;
		}
		
}
