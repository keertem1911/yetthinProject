package com.yetthin.web.domain;

public class StockType {
		private String typeName;	
		private String stockType;
		public String getTypeName() {
			return typeName;
		}
		public void setTypeName(String typeName) {
			this.typeName = typeName;
		}
		public String getStockType() {
			return stockType;
		}
		public void setStockType(String stockType) {
			this.stockType = stockType;
		}
		

}
