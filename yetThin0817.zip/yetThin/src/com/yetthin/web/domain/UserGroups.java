package com.yetthin.web.domain;

public class UserGroups {
	private String groupName;	
	private String imcomeRatio; 
	private String createTime; 
 
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public String getImcomeRatio() {
		return imcomeRatio;
	}
	public void setImcomeRatio(String imcomeRatio) {
		this.imcomeRatio = imcomeRatio;
	}
	public String getCreateTime() {
		return createTime;
	}
	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}
	 
	
}
