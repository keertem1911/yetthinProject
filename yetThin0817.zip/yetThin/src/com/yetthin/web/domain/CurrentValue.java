package com.yetthin.web.domain;

public class CurrentValue {
	private String time;
	private String incomeRate;
	private String indexWaveRate;
 
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getIncomeRate() {
		return incomeRate;
	}
	public void setIncomeRate(String incomeRate) {
		this.incomeRate = incomeRate;
	}
	public String getIndexWaveRate() {
		return indexWaveRate;
	}
	public void setIndexWaveRate(String indexWaveRate) {
		this.indexWaveRate = indexWaveRate;
	}
	 
	
}
