package com.yetthin.web.domain;

public class Evaluation {
		private String number;
		private String statusNum;
		private String status;
		public String getNumber() {
			return number;
		}
		public void setNumber(String number) {
			this.number = number;
		}
		public String getStatusNum() {
			return statusNum;
		}
		public void setStatusNum(String statusNum) {
			this.statusNum = statusNum;
		}
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		
}
