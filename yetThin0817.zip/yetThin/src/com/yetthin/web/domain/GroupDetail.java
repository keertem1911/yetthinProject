package com.yetthin.web.domain;

public class GroupDetail {
	private String groupName ;
	private String emotionIndex ;
	private String totleIncome ;
	private String evaluateLevel ;
	private String dayIncome ;
	private String monthIncome ;
	private String netIncome ;
	private String userImg;
	private String userName ;
	private String userId ;
	private String vipFlag ;
	private String belongDepart ;
	private String near3MonthIncome ;
	private String latestChangeShareTime ;
	
	public String getUserImg() {
		return userImg;
	}
	public void setUserImg(String userImg) {
		this.userImg = userImg;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public String getEmotionIndex() {
		return emotionIndex;
	}
	public void setEmotionIndex(String emotionIndex) {
		this.emotionIndex = emotionIndex;
	}
	public String getTotleIncome() {
		return totleIncome;
	}
	public void setTotleIncome(String totleIncome) {
		this.totleIncome = totleIncome;
	}
	public String getEvaluateLevel() {
		return evaluateLevel;
	}
	public void setEvaluateLevel(String evaluateLevel) {
		this.evaluateLevel = evaluateLevel;
	}
	public String getDayIncome() {
		return dayIncome;
	}
	public void setDayIncome(String dayIncome) {
		this.dayIncome = dayIncome;
	}
	public String getMonthIncome() {
		return monthIncome;
	}
	public void setMonthIncome(String monthIncome) {
		this.monthIncome = monthIncome;
	}
	public String getNetIncome() {
		return netIncome;
	}
	public void setNetIncome(String netIncome) {
		this.netIncome = netIncome;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getVipFlag() {
		return vipFlag;
	}
	public void setVipFlag(String vipFlag) {
		this.vipFlag = vipFlag;
	}
	public String getBelongDepart() {
		return belongDepart;
	}
	public void setBelongDepart(String belongDepart) {
		this.belongDepart = belongDepart;
	}
	public String getNear3MonthIncome() {
		return near3MonthIncome;
	}
	public void setNear3MonthIncome(String near3MonthIncome) {
		this.near3MonthIncome = near3MonthIncome;
	}
	public String getLatestChangeShareTime() {
		return latestChangeShareTime;
	}
	public void setLatestChangeShareTime(String latestChangeShareTime) {
		this.latestChangeShareTime = latestChangeShareTime;
	}
	

}
