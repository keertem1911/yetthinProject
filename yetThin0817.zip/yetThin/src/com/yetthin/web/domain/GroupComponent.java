package com.yetthin.web.domain;

public class GroupComponent {
	private String referIndustryRatio ;
	private String referKindRatio ;
	private String sumFund ;
	private String freeFund ;
	public String getReferIndustryRatio() {
		return referIndustryRatio;
	}
	public void setReferIndustryRatio(String referIndustryRatio) {
		this.referIndustryRatio = referIndustryRatio;
	}
	public String getReferKindRatio() {
		return referKindRatio;
	}
	public void setReferKindRatio(String referKindRatio) {
		this.referKindRatio = referKindRatio;
	}
	public String getSumFund() {
		return sumFund;
	}
	public void setSumFund(String sumFund) {
		this.sumFund = sumFund;
	}
	public String getFreeFund() {
		return freeFund;
	}
	public void setFreeFund(String freeFund) {
		this.freeFund = freeFund;
	}
	
}
