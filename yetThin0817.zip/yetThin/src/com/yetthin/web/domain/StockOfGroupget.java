package com.yetthin.web.domain;

public class StockOfGroupget {
	private String stockName;	
	private String stockCode;	
	private String stockType;	
	private String stockRatio;
	public String getStockName() {
		return stockName;
	}
	public void setStockName(String stockName) {
		this.stockName = stockName;
	}
	public String getStockCode() {
		return stockCode;
	}
	public void setStockCode(String stockCode) {
		this.stockCode = stockCode;
	}
	public String getStockType() {
		return stockType;
	}
	public void setStockType(String stockType) {
		this.stockType = stockType;
	}
	public String getStockRatio() {
		return stockRatio;
	}
	public void setStockRatio(String stockRatio) {
		this.stockRatio = stockRatio;
	}	
	
}
