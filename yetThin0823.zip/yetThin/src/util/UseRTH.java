package util;

public enum UseRTH {
	NONUSE_RTH,
	USE_RTH
}
