package util;

public class OrderCombination {

	public long tickId;
	public Contract contract;
	public Order order;
	
	public OrderCombination() {
		// TODO Auto-generated constructor stub
	}

}
