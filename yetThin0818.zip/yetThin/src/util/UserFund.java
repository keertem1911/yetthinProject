package util;

public class UserFund {

	public UserFund() {
		// TODO Auto-generated constructor stub
	}

}
