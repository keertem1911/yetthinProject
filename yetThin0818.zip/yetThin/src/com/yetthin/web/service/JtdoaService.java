package com.yetthin.web.service;

public interface JtdoaService {

	String[] getL1(int huShen,int begin,int end, String market);

	String[] getL2(String upperCase);

}
