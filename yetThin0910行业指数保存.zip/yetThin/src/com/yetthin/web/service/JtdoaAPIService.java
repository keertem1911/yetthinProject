package com.yetthin.web.service;

public interface JtdoaAPIService {

}
