package com.yetthin.web.test;

import java.util.Arrays;

import util.CYCTYPE;

public class EnumTest {
	public static void main(String[] args) {
		CYCTYPE [] values= CYCTYPE.values();
		System.out.println(values[2]);
	}
}
