package zcom.yetthin.web.controller;

import org.springframework.stereotype.Component;

@Component
public class ClassC {
	public void print(){
		System.out.println("hello classC");
	}
}
