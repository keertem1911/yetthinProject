package zcom.yetthin.web.controller;

import org.springframework.stereotype.Component;

@Component
public class ClassB {
	public void print(){
		System.out.println("hello classB");
	}
}
