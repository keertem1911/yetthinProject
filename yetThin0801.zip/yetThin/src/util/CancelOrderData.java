package util;

public class CancelOrderData {

	public long tickId;
	public long orderId;
	public CancelOrderData() {
		// TODO Auto-generated constructor stub
	}

}
