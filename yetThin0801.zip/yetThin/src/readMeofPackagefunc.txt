com.yetthin.web 为顶级包名  
控制层为 controller
业务层  接口为 service 实现类 serviceImp
数据持久层 为 persistence
模型实体类层 为 domain
 						