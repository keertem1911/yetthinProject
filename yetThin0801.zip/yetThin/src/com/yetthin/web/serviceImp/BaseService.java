package com.yetthin.web.serviceImp;


public class BaseService {
		

}
