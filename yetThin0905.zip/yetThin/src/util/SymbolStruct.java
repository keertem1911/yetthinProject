package util;

public class SymbolStruct {

	public SymbolStruct() {
		// TODO Auto-generated constructor stub
	}

}
